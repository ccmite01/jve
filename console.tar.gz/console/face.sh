#!/bin/bash

rm -f /var/www/html/console/face/*.png
cp -p /opt/minecraft/${MC_INSTANCE_NAME}/plugins/dynmap/web/tiles/faces/32x32/*.png /var/www/html/console/face/
