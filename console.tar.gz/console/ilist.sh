#!/bin/bash

#grep "logged in with entity" /opt/minecraft/${MC_INSTANCE_NAME}/logs/latest.log


grep "logged in with entity" /opt/minecraft/${MC_INSTANCE_NAME}/logs/latest.log | sed 's/ \[Server thread\/INFO\]\://g' | sed 's/:[0-9]*] logged in .*$//g' | sed 's/\[\// /g' | sed '$!s/$/,/g' 

