#!/bin/bash

whois $1 | grep "inetnum\|inet6num\|netname\|descr\|country\|source\|role\|itr\|NetRange\|Organization" | grep -v esource

