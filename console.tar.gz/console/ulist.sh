#!/bin/bash

PASS=`grep rcon\.password /opt/minecraft/${MC_INSTANCE_NAME}/server.properties | awk -F '[=]' '{print $2}'`
USRLIST=`/var/www/html/console/mcrcon -H "localhost" -P 25575 -p ${PASS} list`
USRLIST2=`echo ${USRLIST} | awk -F '[:]' '{print $2}'`
USRLIST3=`echo $USRLIST2 | sed -e 's/\\[0m//g'`

echo $USRLIST3
