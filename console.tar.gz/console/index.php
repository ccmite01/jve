<?php
  session_start();
  $error_message = "";
  if(isset($_POST["login"])) {
      if($_POST["user_name"] == "admin" && $_POST["password"] == "do_not_copy_and_paste") {
          $_SESSION["user_name"] = $_POST["user_name"];
          $login_success_url = "console.php";
          header("Location: {$login_success_url}");
          exit;
      }
      
  $error_message = "いたずらしないでね";
  }
?>

<?php
  if($error_message) {
        echo $error_message;
  }
?>

<form action="index.php" method="POST">
  <p>おなまえ：<input type="text" name="user_name"></p>
  <p>か　　ぎ：<input type="password" name="password"></p>
  <input type="submit" name="login" value="はいる">
</form>
